<html>
<head>
	<title></title>

</head>
<body>
	<div class="wrapper">
		<aside>
		<ul>
			<li id="opcion1">Opcion 1</li>
			<li id="opcion2">Opcion 2</li>
			<li id="opcion3">Opcion 3</li>

		</ul>
		</aside>
		<section>
			<div id="box"></div>
		</section>
		<div class="clear"></div>
	</div>
	<script type="text/javascript" src="main.js"></script>

</body>
</html>

<style type="text/css">
*{margin: 0;
padding: 0;
}
.wrapper{
	width: 970px;
	margin: 0 auto;
}
aside{
	width: 300px;
	float: left;
}
section{
	width: 670px;
	float: left;
}
.clear{
	clear: both;
}
</style>